<?php
require 'function.php';
$view_info_2=view_info_2();   /// for view function


//delete function
if(isset($_GET['status'])){
    $delete_id_rec=$_GET['id'];
    $delete=delete($delete_id_rec);//parrametter pass
}


?>
<html>
<head>
<link href="css/contract.css" rel="stylesheet"/>
<link href="fonts/stylesheet.css" rel="stylesheet"/>
<!--2st slider-->


    <link href="css/nivo-slider.css" rel="stylesheet"/>
	<link href="themes/dark/dark.css" rel="stylesheet"/>
	<!--   end    -->
</head>
<body>




<div class="whole">
	<header style="width="960px" height="300px">
			<img src="images/r.PNG" style="width="960px" height="300px"/>
	</header>
	
	<div id="sticker">
	<div class="menu">
				<ul>
						<li><a href="index.php"> Home</a></li>
						<li><a href="#">Islamic Foram</a>
								<ul>
									<li><a href="al-quran.html">Al Quran</a></li>
									<li><a href="al-hadith.html">Al Hadith</a></li>
									<li><a href="video.html">Video</a></li>
									<li><a href="audio.html">Audio</a></li>
									<li><a href="book.html">Boook</a></li>	
								</ul>
						</li>
						<li><a href="#">Software </a>
								<ul>
									<li><a href="java.html">java</a></li>
									<li><a href="android.html">Android</a></li>
									<li><a href="Windows.html">Windows</a></li>
									<li><a href="pc-soft.html">PC Soft</a></li>
								</ul>
						</li>
						<li><a href="#">Tips & Tricks</a>
								<ul>
									<li><a href="facebook.html">Facebook</a></li>
									<li><a href="hacking.html">Hacking</a></li>
									<li><a href="hardware.html">Hardware </a></li>
									<li><a href="pc-tips.html">PC Tips</a></li>
								</ul>
						</li>
						<li><a href="#">Tutorial</a>
								<ul>
									<li><a href="tutorial.html">Html</a></li>
									<li><a href="css.html">Css</a></li>
									<li><a href="php.html">php</a></li>
									<li><a href="photoshop.html">photoshop</a></li>
									<li><a href="wordpress.html">Wordpress</a></li>
								</ul>
						</li>
						<li><a href="add_info.php">Registration </a></li>
				</ul>
	</div>
</div>		
		

	<div class="main_containt">
		
					

<hr/>
<h1 style="text-align: center;color:green;">View  Blog Info</h1>
<h2 style="text-align: center;color:green;"><?php if(isset($delete)) echo $delete;?></h2>
<hr/>

<a href="add_info.php" style="margin:10px;float:left;text-decoration: none;color:red">ADD Your Blog Info</a>
<a href="view_info.php" style="margin:10px;float:right;text-decoration: none;color:green">View Your Blog Info</a>
<hr/><hr/><hr/><hr/><hr/>

<table width="800px" border="2" style="cell-spaceing:20;margin-top:15px" align="center" >
    <tr align="center">
        <td>ID</td>
        <td>Title Name</td>
        <td>Author Name</td>
        <td>Blog Description</td>
        <td>Publication Status</td>  
        <td>Edit Option</td> 
        <td>Delete Option</td> 
    </tr>
  <?php while($view= mysqli_fetch_assoc($view_info_2)) {?>
     <tr>
        <td><?php echo $view['d_id']; ?></td>
        <td><?php echo $view['d_name']; ?></td>
        <td><?php echo $view['d_email']; ?></td>
        <td><?php echo $view['d_address']; ?></td>
        
        <td>
           <?php echo $view['d_batch']; ?>
        </td>  
        <td align="center">
            <a href="update_info.php?idsend=<?php echo $view['d_id'];?>" style="text-decoration:none;color:green;background-color:palegoldenrod"> Edit Here</a>        
        </td><td align="center"> 
            <a href="?status=delete&&id=<?php echo $view['d_id'] ;?>" style="text-decoration:none;color:whitesmoke;background-color:purple">Delete </a>
        </td>
    </tr>
  <?php }?>
</table>

					
		</div>
			
				
		
	
	
		<footer>
		
			  <p><a href="https://www.facebook.com/MuhammadRummanIslam">
			  Powered by:Muhammad Rumman islam Nur</a>.</p>
		 
		</footer>
		

	
</div>


					<!-- use of java script-->
					<!-- use of 1 java script-->
		<script>
			$('container').pureSlider({
				slideNode: 'slide'
			});
		</script>
		<!-- use of  2 java script-->
    <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
			<!-- use of java script-->
			
		<script type="text/javascript">
$(document).ready(function() {
	var s = $("#sticker");
	var pos = s.position();					   
	$(window).scroll(function() {
		var windowpos = $(window).scrollTop();
		
		if (windowpos >= pos.top) {
			s.addClass("stick");
		} else {
			s.removeClass("stick");	
		}
	});
});
</script>
		
</body>
</html>
