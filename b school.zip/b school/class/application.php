<?php

/**
 * @author rumman
 */
class Application {

    private $db_connect;

    public function __construct() {
        // just connect database 
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'template';
        $this->db_connect = mysqli_connect($host, $user, $password, $database);
        if (!$this->db_connect) {
            die("Database Not Connect Successfully !!" . mysqli_error($this->db_connect));
        }
    }

    public function select_all_published_category() {
        $query = "select * from tbl_category where publication_status='1'";
        if (mysqli_query($this->db_connect, $query)) {
            $result = mysqli_query($this->db_connect, $query);
            return $result;
        } else {
            die(" Query Problem " . mysqli_errno($this->db_connect));
        }
    }

	
	 public function reg_info($data){
		 $data1=md5($data['password']);
		 $query = "insert into tbl_admin(db_name,db_email,db_password) values('$data[name]','$data[email]','$data1')";
        if (mysqli_query($this->db_connect, $query)) {
            $result ="Congratulation !! Admin Registration Successfully";
            return $result;
        } else {
            die(" Query Problem " . mysqli_error($this->db_connect));
        }
	 }
}
