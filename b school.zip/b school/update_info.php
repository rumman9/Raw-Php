<?php
require 'function.php';

// select database data by id----------------------------------------------------
$received_id=$_GET['idsend'];                     //received id ja send by view page
$select_info=select_info($received_id);           //paramitter pass
$a_data_rec= mysqli_fetch_assoc($select_info);    // array data received
//end selict_info---------------------------------------------------------------

if(isset($_POST['btn'])){
    update_info(); 
}


?>

<html>
<head>
<link href="css/contract.css" rel="stylesheet"/>
<link href="fonts/stylesheet.css" rel="stylesheet"/>
<!--2st slider-->


    <link href="css/nivo-slider.css" rel="stylesheet"/>
	<link href="themes/dark/dark.css" rel="stylesheet"/>
	<!--   end    -->
</head>
<body>




<div class="whole">
	<header style="width="960px" height="300px">
			<img src="images/r.PNG" style="width="960px" height="300px"/>
	</header>
	
	<div id="sticker">
	<div class="menu">
				<ul>
						<li><a href="index.php"> Home</a></li>
						<li><a href="#">Islamic Foram</a>
								<ul>
									<li><a href="al-quran.html">Al Quran</a></li>
									<li><a href="al-hadith.html">Al Hadith</a></li>
									<li><a href="video.html">Video</a></li>
									<li><a href="audio.html">Audio</a></li>
									<li><a href="book.html">Boook</a></li>	
								</ul>
						</li>
						<li><a href="#">Software </a>
								<ul>
									<li><a href="java.html">java</a></li>
									<li><a href="android.html">Android</a></li>
									<li><a href="Windows.html">Windows</a></li>
									<li><a href="pc-soft.html">PC Soft</a></li>
								</ul>
						</li>
						<li><a href="#">Tips & Tricks</a>
								<ul>
									<li><a href="facebook.html">Facebook</a></li>
									<li><a href="hacking.html">Hacking</a></li>
									<li><a href="hardware.html">Hardware </a></li>
									<li><a href="pc-tips.html">PC Tips</a></li>
								</ul>
						</li>
						<li><a href="#">Tutorial</a>
								<ul>
									<li><a href="tutorial.html">Html</a></li>
									<li><a href="css.html">Css</a></li>
									<li><a href="php.html">php</a></li>
									<li><a href="photoshop.html">photoshop</a></li>
									<li><a href="wordpress.html">Wordpress</a></li>
								</ul>
						</li>
						<li><a href="add_info.php">Registration </a></li>
				</ul>
	</div>
</div>		
		

	<div class="main_containt">
		<div class="content">
					<hr/>
<h1 style="text-align: center;color:green;">Update/Edit A student Information</h1>
<h2 style="text-align: center;color:green;"><?php if(isset($add_info)) echo $add_info;?></h2>
<hr/>

<a href="add_info.php" style="margin:10px;float:left;text-decoration: none;color:red">ADD Your Blog Info</a>
<a href="view_info.php" style="margin:10px;float:right;text-decoration: none;color:green;">View Your Blog Info</a>
<hr/><hr/><hr/><hr/><hr/>

<form action="" method="post">
    <table style="cell-padding:15;cell-spaceing:20;" align="center" >
        <tr>
            <td>Full Name</td>
            <td><input type="text" name="name" value="<?php  echo $a_data_rec['d_name'];?>" /> <input type="text" name="hidden_id" value="<?php  echo $a_data_rec['d_id'];?>"  /></td>
        </tr>
        <tr>
            <td>Email/phone </td>
            <td><input type="text" value="<?php  echo $a_data_rec['d_email'];?>" name="email"/> </td>
        </tr>
        <tr>
            <td> Your Address </td>
            <td> <textarea name="address"  cols="50" rows="15"><?php  echo $a_data_rec['d_address'];?></textarea></td>
        </tr>
        <tr>
            <td>Batch </td>
            <td>
                <select name="batch" style='color:green'>
                    <option style='color:black' >--- Select a option ---</option>
                    <option value="33A">33A  </option>
                    <option value='32A'> 32A </option>
					<option value='34c'> 34c </option>
					<option value='35z'> 35z </option>
                </select>
            </td>
        </tr>
        <tr>
            <td> </td>
            <td><input type="submit" name="btn" value="Update Information" style="color:green;"/>
               </td>
        </tr>

    </table>
</form>
					
		</div>
			
				<div class="sidebar">
						<h3><em>Web Devloping</em></h3>
						<ul>
							<li><a href="#">&#187; Html</a></li>
							<li><a href="#">&#187; CSS</a></a> </li>
							<li><a href="#">&#187; java script</a></li>
							<li><a href="#">&#187; Php </a></li>
							<li><a href="#">&#187; SEO</a></li>
						</ul>
						<h3><em>programing</em></h3>
						<ul>
							<li><a href="#">&#9733; programing C</a></li>
							<li><a href="">&#9733; Java</a></a> </li>
							<li><a href="">&#9733; phython</a></li>
							<li><a href="">&#9733; C++/C#</a></li>
							<li><a href="">&#9733; Android</a></li>
						</ul>
						<h3><em>Other Site</em></h3>
						<ul>
							<li><a href="">&#9758; EDU Board</a></li>
							<li><a href="">&#9758; Bdnews</a></a> </li>
							<li><a href="">&#9758; Facebook </a></li>
							
							<li><a href="">&#9758; Android </a></li>
						</ul>
				</div>
		</div>
	
	
		<footer>
		
			  <p><a href="https://www.facebook.com/MuhammadRummanIslam">
			  Powered by:Muhammad Rumman islam Nur</a>.</p>
		 
		</footer>
		

	
</div>


					<!-- use of java script-->
					<!-- use of 1 java script-->
		<script>
			$('container').pureSlider({
				slideNode: 'slide'
			});
		</script>
		<!-- use of  2 java script-->
    <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
			<!-- use of java script-->
			
		<script type="text/javascript">
$(document).ready(function() {
	var s = $("#sticker");
	var pos = s.position();					   
	$(window).scroll(function() {
		var windowpos = $(window).scrollTop();
		
		if (windowpos >= pos.top) {
			s.addClass("stick");
		} else {
			s.removeClass("stick");	
		}
	});
});
</script>
		
</body>
</html>
