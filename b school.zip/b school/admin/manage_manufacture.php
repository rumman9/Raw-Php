<?php

$pages="manage_manu";
include './admin_master.php';
