<?php

$pages="add_manu";
include './admin_master.php';

