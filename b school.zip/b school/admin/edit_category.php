<?php

$pages="edit";
include './admin_master.php';