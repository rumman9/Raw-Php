<?php

/**
 * Description of admin
 *
 * @author rumman
 */
class Admin {

    //put your code here
    private $db_connect;

    public function __construct() {
        // just connect database 
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'template';
        $this->db_connect = mysqli_connect($host, $user, $password, $database);
        if (!$this->db_connect) {
            die("Database Not Connect Successfully !!" . mysqli_error($this->db_connect));
        }
    }

    public function admin_login_check($data) {
//        echo "<pre>";  print_r($data);  exit();       //  just check
        $email = $data['email'];              //user given email
        $password = md5($data['password']);           //user given password

        $query = "select * from tbl_admin where db_email='$email' and db_password='$password' ";

        if (mysqli_query($this->db_connect, $query)) {
            $query_result = mysqli_query($this->db_connect, $query);
            $admin_info = mysqli_fetch_assoc($query_result);

            if ($admin_info) {

                session_start();
                $_SESSION['author_name'] = $admin_info['db_name'];  // author name variabl
                $_SESSION['author_id']   = $admin_info['db_id'];     //admin query data joma and database admin id

                header('location:admin_master.php');
            } else {
                $massage = "Your Email Address Or Password is Incorrect";
                return $massage;
            }
        } else {
            die('Query Problem !! ' . mysqli_error($this->db_connect));
        }
    }

}
