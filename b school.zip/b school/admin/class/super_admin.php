<?php

/**
 * Description of super_admin
 *
 * @author rumman
 */
class Super_admin {

    //put your code here
    private $db_connect;

    //this is  a connection for catagorie page 
    public function __construct() {
        // just connect database 
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'template';
        $this->db_connect = mysqli_connect($host, $user, $password, $database);
        if (!$this->db_connect) {
            die("Database Not Connect Successfully !!" . mysqli_error($this->db_connect));
        }
    }

    public function save_categor_info($data) {
        $query = "insert into tbl_category(category_name,category_description,publication_status) values('$data[category_name]','$data[category_description]','$data[publication_status]')";

        if (mysqli_query($this->db_connect, $query)) {
            $massage = "Congaratulation data Insert Succesfully  !!";
            return $massage;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
//       echo '<pre>';
//       print_r($data);
//        echo '</pre>';
    }

    // catagories add function exit 
    // this function is for view database data
    public function select_all_category_info() {
        $query = "select * from tbl_category";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = mysqli_query($this->db_connect, $query);
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    //function for select info from database

    public function select_info_from_database($data) {
        $query = "select * from tbl_category where category_id='$data'";
        if (mysqli_query($this->db_connect, $query)) {
            $query_data = mysqli_query($this->db_connect, $query);
            return $query_data;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // updatate function
    public function update_information() {
        $query = "update tbl_category set category_name='$_POST[category_name]' ,category_description='$_POST[category_description]',publication_status='$_POST[publication_status]' where category_id='$_POST[hidden_id]' ";
        if (mysqli_query($this->db_connect, $query)) {

            // sessoin e a ta massage rakhbo
            $_SESSION['massage'] = 'Oh congratulation !! Update data successfully';
            header('location:manage_category.php');
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

// this is for published unpublished 

    public function unpublished_catagori_by_id($catagori_id) {
        $query = "update tbl_category set publication_status='0' where category_id='$catagori_id' ";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = "catagori info unpublished successfully ";
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // unpublished

    public function published_catagori_by_id($catagori_id) {
        $query = "update tbl_category set publication_status='1' where category_id='$catagori_id' ";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = "catagori info published successfully ";
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    //delete function 
    function delete_categori_by_id($data) {
        $query = "delete from tbl_category where category_id='$data' ";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = "delete information successfully ";
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // insert manufacture
    function add_manufacture($data) {
        $query = "insert into tbl_manu(d_manu_name,d_manu_description,d_publication_status) values('$data[manu_name]','$data[manu_description]','$data[publication_status]')";

        if (mysqli_query($this->db_connect, $query)) {
            $massage = "Congaratulation data Insert Succesfully  !!";
            return $massage;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // view manufacture 
    // this function is for view database data
    public function view_manufacture() {
        $query = "select * from tbl_manu";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = mysqli_query($this->db_connect, $query);
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // //function for select info from database

    public function select_info_from_database_manu($data) {
        $query = "select * from tbl_manu where 	d_manu_id='$data'";
        if (mysqli_query($this->db_connect, $query)) {
            $query_data = mysqli_query($this->db_connect, $query);
            return $query_data;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // updatate function
    public function update_information_manufac() {
        $query = "update tbl_manu set d_manu_name='$_POST[manu_name]' ,d_manu_description='$_POST[manu_description]',d_publication_status='$_POST[publication_status]' where d_manu_id='$_POST[hidden_id]' ";
        if (mysqli_query($this->db_connect, $query)) {
            $result = "Oh congratulation !! Update data successfully";
            return $result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // this is for  manufacture published unpublished 

    public function unpublished_manufac_by_id($manufacture_id) {
        $query = "update tbl_manu set d_publication_status='0' where d_manu_id='$manufacture_id' ";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = "manufacture info unpublished successfully ";
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    // unpublished

    public function published_manufac_by_id($manufacture_id) {
        $query = "update tbl_manu set d_publication_status='1' where d_manu_id='$manufacture_id' ";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = "manufacture info published successfully ";
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    //delete function 
    function delete_manufac_by_id($data) {
        $query = "delete from tbl_manu where d_manu_id='$data' ";
        if (mysqli_query($this->db_connect, $query)) {
            $view_result = "delete information successfully ";
            return $view_result;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }

    //end



    public function logout() {

        unset($_SESSION['author_name']); //session take unset kore deya holo
        unset($_SESSION['author_id']);

        header('location:index.php');
    }

}
