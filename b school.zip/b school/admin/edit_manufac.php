<?php

$pages="edit_manufac";
include './admin_master.php';