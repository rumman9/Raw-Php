<?php

        $host       ="localhost";
        $user       ="root";
        $password   ="";
        $database   ="rumman";
        
        $server_connect= mysqli_connect($host, $user, $password, $database);
        if(!$server_connect){
            die("server not connected".mysqli_error($server_connect));
        }
     
 //-------------------function for add data 
        
    function add_info(){ 
        global $server_connect;
        $query="insert into tbl_16(d_name,d_email,d_address,d_batch) values('$_POST[name]','$_POST[email]','$_POST[address]','$_POST[batch]' )";
       
        if(mysqli_query($server_connect, $query)){
            $show_massage="Congratulation !..add data successfully";
            return $show_massage;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
    
    
    // -----------------function  for view data-------------------------------
    
    function view_info(){
        global $server_connect;
        $query="select * from tbl_16";
       
        if(mysqli_query($server_connect, $query)){
            $query_data=mysqli_query($server_connect, $query);
            return $query_data;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
    
     // -----------------function  for view data-------------------------------
    
    function view_info_1(){
        global $server_connect;
        $query="select * from tbl_16 where d_batch='33A'";
       
        if(mysqli_query($server_connect, $query)){
            $query_data=mysqli_query($server_connect, $query);
            return $query_data;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
    
	// -----------------function  for view data-------------------------------
    
    function view_info_2(){
        global $server_connect;
        $query="select * from tbl_16 where d_batch='32A'";
       
        if(mysqli_query($server_connect, $query)){
            $query_data=mysqli_query($server_connect, $query);
            return $query_data;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
	
	// -----------------function  for view data-------------------------------
    
    function view_info_3(){
        global $server_connect;
        $query="select * from tbl_16 where d_batch='34c'";
       
        if(mysqli_query($server_connect, $query)){
            $query_data=mysqli_query($server_connect, $query);
            return $query_data;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
	
	
	// -----------------function  for view data-------------------------------
    
    function view_info_4(){
        global $server_connect;
        $query="select * from tbl_16 where d_batch='35z'";
       
        if(mysqli_query($server_connect, $query)){
            $query_data=mysqli_query($server_connect, $query);
            return $query_data;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
	
	
	
	
    // function for select info from database------------------------------------
    function select_info($received){
       global $server_connect;
        $query="select * from tbl_16 where d_id='$received' ";
       
        if(mysqli_query($server_connect, $query)){
            $query_data=mysqli_query($server_connect, $query);
            return $query_data;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
    
    
    // function for update--------------------------------------------------
   
    function update_info(){
         global $server_connect;
        $query="update tbl_16 set d_name='$_POST[name]',d_email='$_POST[email]',d_address='$_POST[address]',d_batch='$_POST[batch]' where d_id='$_POST[hidden_id]' ";
       
        if(mysqli_query($server_connect, $query)){
            
           header('location:view_info.php');
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
    
    
    
    
    // function for delete info
    
    function delete($data){ // received parametter
        global $server_connect;
        $query="delete from tbl_16 where d_id='$data'";
       
        if(mysqli_query($server_connect, $query)){
                $result="delete successfully";
                return $result;
           }else{
                 die("not connect". mysqli_error($server_connect));
           }
    }
    
    
    ?>